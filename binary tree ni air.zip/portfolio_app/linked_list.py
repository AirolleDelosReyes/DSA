"""A simple singly linked list used by the /works/linkedlist page."""


class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        node = Node(data)
        if self.head is None:
            self.head = node
            return
        cur = self.head
        while cur.next:
            cur = cur.next
        cur.next = node

    def prepend(self, data):
        node = Node(data)
        node.next = self.head
        self.head = node

    def insert_at(self, index, data):
        """Insert at a 0-based position. Returns False if the index is out of range."""
        if index < 0:
            return False
        if index == 0:
            self.prepend(data)
            return True
        cur = self.head
        for _ in range(index - 1):
            if cur is None:
                return False
            cur = cur.next
        if cur is None:
            return False
        node = Node(data)
        node.next = cur.next
        cur.next = node
        return True

    def delete(self, data):
        """Delete the first node holding `data`. Returns True if something was removed."""
        cur, prev = self.head, None
        while cur:
            if cur.data == data:
                if prev:
                    prev.next = cur.next
                else:
                    self.head = cur.next
                return True
            prev, cur = cur, cur.next
        return False

    def search(self, data):
        """Return the 0-based index of `data`, or -1 if not found."""
        cur, i = self.head, 0
        while cur:
            if cur.data == data:
                return i
            cur, i = cur.next, i + 1
        return -1

    def reverse(self):
        prev, cur = None, self.head
        while cur:
            cur.next, prev, cur = prev, cur, cur.next
        self.head = prev

    def clear(self):
        self.head = None

    def to_list(self):
        items, cur = [], self.head
        while cur:
            items.append(cur.data)
            cur = cur.next
        return items
