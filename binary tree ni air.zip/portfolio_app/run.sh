#!/usr/bin/env bash
cd "$(dirname "$0")"
if [ ! -d venv ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi
source venv/bin/activate
echo "Installing requirements..."
pip install -r requirements.txt
echo
echo "Starting the site at http://127.0.0.1:5000  (press Ctrl+C to stop)"
python app.py
