"""Five sorting algorithms used by the /works/sorting page.

Every algorithm works on a copy of the list and records its steps, so the web
page can show how the list changes. Each run also counts comparisons and
swaps/moves so the algorithms can be compared.
"""

MAX_ITEMS = 30


class SortError(ValueError):
    """Raised when the input can't be sorted."""


# name, one-line idea, best / average / worst time, extra space, stable?
ALGORITHMS = {
    "bubble": {
        "name": "Bubble sort",
        "idea": "Compare neighbours and swap them if they are in the wrong order. After each pass the largest remaining item has bubbled to the end.",
        "best": "O(n)", "average": "O(n²)", "worst": "O(n²)", "space": "O(1)", "stable": "Yes",
    },
    "selection": {
        "name": "Selection sort",
        "idea": "Find the smallest item in the unsorted part and swap it into the next position at the front.",
        "best": "O(n²)", "average": "O(n²)", "worst": "O(n²)", "space": "O(1)", "stable": "No",
    },
    "insertion": {
        "name": "Insertion sort",
        "idea": "Take the next item and slide it left into its correct place among the items already sorted, like sorting playing cards in your hand.",
        "best": "O(n)", "average": "O(n²)", "worst": "O(n²)", "space": "O(1)", "stable": "Yes",
    },
    "merge": {
        "name": "Merge sort",
        "idea": "Split the list in half again and again, then merge the sorted halves back together. Divide and conquer.",
        "best": "O(n log n)", "average": "O(n log n)", "worst": "O(n log n)", "space": "O(n)", "stable": "Yes",
    },
    "quick": {
        "name": "Quick sort",
        "idea": "Pick a pivot (the last item here), move smaller items before it and larger items after it, then sort each side the same way.",
        "best": "O(n log n)", "average": "O(n log n)", "worst": "O(n²)", "space": "O(log n)", "stable": "No",
    },
}


def parse_values(raw):
    """Turn text like '5, 3 8 1' into a list. Numbers if all are numbers, else words."""
    parts = [p for p in raw.replace(",", " ").split() if p]
    if not parts:
        raise SortError("Type some values first, such as 5, 3, 8, 1.")
    if len(parts) > MAX_ITEMS:
        raise SortError(f"Please use at most {MAX_ITEMS} values.")
    try:
        numbers = [float(p) for p in parts]
    except ValueError:
        return parts
    return [int(n) if n.is_integer() else n for n in numbers]


def show(value):
    return str(value)


def show_list(values):
    return "[" + ", ".join(show(v) for v in values) + "]"


def sort_key(value):
    return value.lower() if isinstance(value, str) else value


class Sorter:
    def __init__(self, items, descending=False):
        self.a = list(items)
        self.descending = descending
        self.comparisons = 0
        self.swaps = 0
        self.steps = []

    def before(self, x, y):
        """True if x must come strictly before y. Counts as one comparison."""
        self.comparisons += 1
        kx, ky = sort_key(x), sort_key(y)
        return kx > ky if self.descending else kx < ky

    def swap(self, i, j):
        self.a[i], self.a[j] = self.a[j], self.a[i]
        self.swaps += 1

    def record(self, action, done=(), active=()):
        done, active = set(done), set(active)
        cells = []
        for index, value in enumerate(self.a):
            state = "done" if index in done else "active" if index in active else ""
            cells.append({"value": show(value), "state": state})
        self.steps.append({"action": action, "cells": cells})

    # ---------- the five algorithms ----------
    def bubble(self):
        n = len(self.a)
        self.record("Start")
        for p in range(n - 1):
            start, swapped = self.comparisons, 0
            for j in range(n - 1 - p):
                if self.before(self.a[j + 1], self.a[j]):
                    self.swap(j, j + 1)
                    swapped += 1
            tail = range(n - 1 - p, n)
            self.record(
                f"Pass {p + 1}: {self.comparisons - start} comparisons, {swapped} swaps."
                + ("" if swapped else " No swaps, so the list is sorted."),
                done=range(n) if not swapped else tail,
            )
            if not swapped:
                break

    def selection(self):
        n = len(self.a)
        self.record("Start")
        for i in range(n - 1):
            m = i
            for j in range(i + 1, n):
                if self.before(self.a[j], self.a[m]):
                    m = j
            value = self.a[m]
            if m != i:
                self.swap(i, m)
                action = f"Pass {i + 1}: pick {show(value)} (index {m}) and swap it with index {i}."
            else:
                action = f"Pass {i + 1}: {show(value)} is already in place at index {i}."
            self.record(action, done=range(i + 1), active=[m] if m != i else [])

    def insertion(self):
        a, n = self.a, len(self.a)
        self.record("Start", done=[0] if n else [])
        for i in range(1, n):
            current, j, shifts = a[i], i - 1, 0
            while j >= 0 and self.before(current, a[j]):
                a[j + 1] = a[j]
                j -= 1
                shifts += 1
            a[j + 1] = current
            self.swaps += shifts + (1 if shifts else 0)
            self.record(
                f"Take {show(current)}: shift {shifts} larger item(s) right and insert it at index {j + 1}.",
                done=range(i + 1),
                active=[j + 1],
            )

    def merge(self):
        a = self.a
        self.record("Start")

        def msort(lo, hi):
            if hi - lo < 2:
                return
            mid = (lo + hi) // 2
            msort(lo, mid)
            msort(mid, hi)
            left, right, merged, i, j = a[lo:mid], a[mid:hi], [], 0, 0
            while i < len(left) and j < len(right):
                if self.before(right[j], left[i]):
                    merged.append(right[j])
                    j += 1
                else:
                    merged.append(left[i])
                    i += 1
            merged += left[i:] + right[j:]
            a[lo:hi] = merged
            self.swaps += len(merged)
            self.record(
                f"Merge {show_list(left)} and {show_list(right)} into {show_list(merged)}.",
                active=range(lo, hi),
            )

        msort(0, len(a))

    def quick(self):
        a = self.a
        fixed = set()
        self.record("Start")

        def qsort(lo, hi):
            if lo > hi:
                return
            if lo == hi:
                fixed.add(lo)
                return
            pivot, i = a[hi], lo
            for j in range(lo, hi):
                if self.before(a[j], pivot):
                    if i != j:
                        self.swap(i, j)
                    i += 1
            if i != hi:
                self.swap(i, hi)
            fixed.add(i)
            self.record(
                f"Pivot {show(pivot)}: it lands at index {i}. "
                f"Left side {show_list(a[lo:i])}, right side {show_list(a[i + 1:hi + 1])}.",
                done=fixed,
                active=range(lo, hi + 1),
            )
            qsort(lo, i - 1)
            qsort(i + 1, hi)

        qsort(0, len(a) - 1)


def run(algorithm, items, descending=False):
    sorter = Sorter(items, descending)
    getattr(sorter, algorithm)()
    return sorter


def solve(raw, algorithm, descending=False):
    """Sort `raw` with one algorithm and also compare all five."""
    if algorithm not in ALGORITHMS:
        raise SortError("Choose a sorting algorithm.")
    items = parse_values(raw)

    main = run(algorithm, items, descending)
    final = [{"value": show(v), "state": "done"} for v in main.a]
    main.steps.append({"action": "Sorted.", "cells": final})

    comparison = []
    for key, info in ALGORITHMS.items():
        other = main if key == algorithm else run(key, items, descending)
        comparison.append(
            {
                "key": key,
                "name": info["name"],
                "comparisons": other.comparisons,
                "swaps": other.swaps,
                "steps": len(other.steps) - (1 if key == algorithm else 0),
                "chosen": key == algorithm,
            }
        )

    return {
        "original": show_list(items),
        "sorted": show_list(main.a),
        "info": ALGORITHMS[algorithm],
        "algorithm": algorithm,
        "descending": descending,
        "count": len(items),
        "steps": main.steps,
        "comparisons": main.comparisons,
        "swaps": main.swaps,
        "comparison": comparison,
    }
