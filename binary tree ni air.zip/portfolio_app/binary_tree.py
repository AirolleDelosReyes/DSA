"""A binary search tree used by the /works/binarytree page.

Smaller keys go to the left, larger keys go to the right. Duplicates are ignored.

The three methods from the class activity are:
    search(self, root, key)
    post_traversal(self, start, traversal)
    delete_node(self, root, key)
"""


class TreeNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None


class BinaryTree:
    def __init__(self):
        self.root = None

    # ---------- insert ----------
    def insert(self, key):
        """Add `key` to the tree. Returns False if it is already there."""
        if self.search(self.root, key) is not None:
            return False
        self.root = self._insert(self.root, key)
        return True

    def _insert(self, root, key):
        if root is None:
            return TreeNode(key)
        if key < root.key:
            root.left = self._insert(root.left, key)
        else:
            root.right = self._insert(root.right, key)
        return root

    # ---------- search ----------
    def search(self, root, key):
        """Return the node holding `key`, or None if it is not in the tree.

        Compare with the current node, then go left (smaller) or right (larger).
        """
        if root is None or root.key == key:
            return root
        if key < root.key:
            return self.search(root.left, key)
        return self.search(root.right, key)

    # ---------- traversals ----------
    def post_traversal(self, start, traversal):
        """Post-order: left subtree, right subtree, then the node itself.

        `traversal` is a list that collects the keys in the order they are
        visited. Start with an empty list: tree.post_traversal(tree.root, [])
        """
        if start:
            traversal = self.post_traversal(start.left, traversal)
            traversal = self.post_traversal(start.right, traversal)
            traversal.append(start.key)
        return traversal

    def in_traversal(self, start, traversal):
        """In-order: left, node, right (gives sorted order for a BST)."""
        if start:
            traversal = self.in_traversal(start.left, traversal)
            traversal.append(start.key)
            traversal = self.in_traversal(start.right, traversal)
        return traversal

    def pre_traversal(self, start, traversal):
        """Pre-order: node, left, right."""
        if start:
            traversal.append(start.key)
            traversal = self.pre_traversal(start.left, traversal)
            traversal = self.pre_traversal(start.right, traversal)
        return traversal

    # ---------- delete ----------
    def delete_node(self, root, key):
        """Delete `key` from the subtree at `root` and return the new subtree root.

        Three cases once the node is found:
          1. no children  -> just remove it
          2. one child    -> replace it with that child
          3. two children -> copy the in-order successor (smallest key in the
                             right subtree) into it, then delete the successor
        Use it as: tree.root = tree.delete_node(tree.root, key)
        """
        if root is None:
            return None
        if key < root.key:
            root.left = self.delete_node(root.left, key)
        elif key > root.key:
            root.right = self.delete_node(root.right, key)
        else:
            if root.left is None:
                return root.right
            if root.right is None:
                return root.left
            successor = root.right
            while successor.left:
                successor = successor.left
            root.key = successor.key
            root.right = self.delete_node(root.right, successor.key)
        return root

    # ---------- helpers for the web page ----------
    def clear(self):
        self.root = None

    def height(self, root="__root__"):
        if root == "__root__":
            root = self.root
        if root is None:
            return 0
        return 1 + max(self.height(root.left), self.height(root.right))

    def layout(self):
        """Work out x/y positions for drawing the tree as SVG.

        Returns (nodes, edges, width, height).
        """
        nodes, edges, counter = [], [], [0]
        gap_x, gap_y, pad = 56, 70, 34

        def place(node, depth):
            if node is None:
                return None
            left = place(node.left, depth + 1)
            x = pad + counter[0] * gap_x   # in-order position keeps nodes apart
            counter[0] += 1
            me = {"key": node.key, "x": x, "y": pad + depth * gap_y}
            nodes.append(me)
            right = place(node.right, depth + 1)
            for child in (left, right):
                if child:
                    edges.append((me, child))
            return me

        place(self.root, 0)
        width = pad * 2 + max(counter[0] - 1, 0) * gap_x
        height = pad * 2 + max(self.height() - 1, 0) * gap_y
        return nodes, edges, width, height
