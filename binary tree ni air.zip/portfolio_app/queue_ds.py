"""A FIFO queue (first in, first out) used by the /works/queue page.

Built from linked nodes with both a head and a tail pointer, so enqueue and
dequeue each take constant time. (Named queue_ds.py so it doesn't clash with
Python's built-in `queue` module.)
"""
from linked_list import Node


class Queue:
    def __init__(self):
        self.front = None  # next item to leave
        self.rear = None   # last item that joined
        self.size = 0

    def is_empty(self):
        return self.front is None

    def enqueue(self, data):
        """Add `data` to the rear of the queue."""
        node = Node(data)
        if self.rear is None:
            self.front = self.rear = node
        else:
            self.rear.next = node
            self.rear = node
        self.size += 1

    def dequeue(self):
        """Remove and return the front item. Returns None if the queue is empty."""
        if self.front is None:
            return None
        node = self.front
        self.front = node.next
        if self.front is None:
            self.rear = None
        self.size -= 1
        return node.data

    def peek(self):
        """Return the front item without removing it (None if empty)."""
        return None if self.front is None else self.front.data

    def clear(self):
        self.front = self.rear = None
        self.size = 0

    def to_list(self):
        items, cur = [], self.front
        while cur:
            items.append(cur.data)
            cur = cur.next
        return items
