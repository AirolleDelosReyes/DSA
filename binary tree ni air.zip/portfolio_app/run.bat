@echo off
cd /d "%~dp0"
if not exist venv (
    echo Creating virtual environment...
    python -m venv venv
)
call venv\Scripts\activate.bat
echo Installing requirements...
pip install -r requirements.txt
echo.
echo Starting the site at http://127.0.0.1:5000  (press Ctrl+C to stop)
python app.py
pause
