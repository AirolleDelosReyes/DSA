"""Infix to postfix conversion (shunting-yard) and postfix evaluation.

Both functions record every step so the web page can show the full solution.
"""
import re

# Higher number = binds tighter. "right" means right-associative (2^3^2 = 2^(3^2)).
OPERATORS = {
    "+": (1, "left"),
    "-": (1, "left"),
    "*": (2, "left"),
    "/": (2, "left"),
    "%": (2, "left"),
    "^": (3, "right"),
}

TOKEN_PATTERN = re.compile(r"\s*(\d+\.?\d*|\.\d+|[A-Za-z_]\w*|[-+*/%^()])")


class ExpressionError(ValueError):
    """Raised when the expression can't be read or solved."""


def tokenize(expression):
    """Split text into numbers, variables, operators and parentheses.

    A minus sign at the start, after '(' or after another operator is treated
    as part of the next number (so -5 and 3*-2 work).
    """
    expression = expression.strip()
    if not expression:
        raise ExpressionError("Type an infix expression first.")

    tokens, pos = [], 0
    while pos < len(expression):
        match = TOKEN_PATTERN.match(expression, pos)
        if not match:
            bad = expression[pos:].strip()[0]
            raise ExpressionError(f"Unexpected character '{bad}'.")
        tokens.append(match.group(1))
        pos = match.end()
        if expression[pos:].strip() == "":
            break

    merged, expect_operand, depth = [], True, 0
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        is_operand = tok not in OPERATORS and tok not in "()"
        if tok == "-" and expect_operand:
            nxt = tokens[i + 1] if i + 1 < len(tokens) else ""
            if re.fullmatch(r"\d+\.?\d*|\.\d+", nxt):
                merged.append("-" + nxt)
                expect_operand = False
                i += 2
                continue
            raise ExpressionError("A minus sign can only come before a number, like -5.")
        if is_operand:
            if not expect_operand:
                raise ExpressionError(f"Missing operator before '{tok}'.")
            expect_operand = False
        elif tok == "(":
            if not expect_operand:
                raise ExpressionError("Missing operator before '('.")
            depth += 1
        elif tok == ")":
            if expect_operand:
                raise ExpressionError("Missing a value before ')'.")
            depth -= 1
            if depth < 0:
                raise ExpressionError("There is a ')' without a matching '('.")
        else:  # operator
            if expect_operand:
                raise ExpressionError(f"Missing a value before '{tok}'.")
            expect_operand = True
        merged.append(tok)
        i += 1

    if depth > 0:
        raise ExpressionError("There is a '(' without a matching ')'.")
    if expect_operand:
        raise ExpressionError("The expression ends with an operator.")
    return merged


def infix_to_postfix(tokens):
    """Return (postfix_tokens, steps). Each step has token, action, stack, output."""
    stack, output, steps = [], [], []

    def log(token, action):
        steps.append({
            "token": token,
            "action": action,
            "stack": " ".join(stack),
            "output": " ".join(output),
        })

    for tok in tokens:
        if tok in OPERATORS:
            prec, assoc = OPERATORS[tok]
            popped = []
            while stack and stack[-1] in OPERATORS:
                top_prec = OPERATORS[stack[-1]][0]
                if top_prec > prec or (top_prec == prec and assoc == "left"):
                    popped.append(stack.pop())
                    output.append(popped[-1])
                else:
                    break
            stack.append(tok)
            if popped:
                log(tok, f"Pop {', '.join(popped)} to output (higher or equal priority), then push {tok}")
            else:
                log(tok, f"Push {tok} onto the stack")
        elif tok == "(":
            stack.append(tok)
            log(tok, "Push ( onto the stack")
        elif tok == ")":
            popped = []
            while stack and stack[-1] != "(":
                popped.append(stack.pop())
                output.append(popped[-1])
            stack.pop()  # discard the "("
            if popped:
                log(tok, f"Pop {', '.join(popped)} to output until (, then discard (")
            else:
                log(tok, "Discard the matching (")
        else:
            output.append(tok)
            log(tok, f"Operand, send {tok} to output")

    while stack:
        op = stack.pop()
        output.append(op)
        log("end", f"Pop {op} to output")

    return output, steps


def _fmt(value):
    """Show whole numbers without .0 and trim long decimals."""
    if isinstance(value, float):
        if value == int(value) and abs(value) < 1e15:
            return str(int(value))
        return f"{value:.6f}".rstrip("0").rstrip(".")
    return str(value)


def _is_number(tok):
    try:
        float(tok)
        return True
    except ValueError:
        return False


def _apply(op, a, b):
    if op == "+":
        return a + b
    if op == "-":
        return a - b
    if op == "*":
        return a * b
    if op in "/%" and b == 0:
        raise ExpressionError("Division by zero.")
    if op == "/":
        return a / b
    if op == "%":
        return a % b
    try:
        result = a ** b
    except OverflowError:
        raise ExpressionError("The result is too large to compute.")
    if isinstance(result, complex):
        raise ExpressionError("That power doesn't give a real number.")
    return result


def evaluate_postfix(postfix):
    """Return (answer, steps), or (None, []) if the expression has variables."""
    if not all(tok in OPERATORS or _is_number(tok) for tok in postfix):
        return None, []

    stack, steps = [], []
    for tok in postfix:
        if tok in OPERATORS:
            b, a = stack.pop(), stack.pop()
            value = _apply(tok, a, b)
            action = f"Pop {_fmt(b)} and {_fmt(a)}, compute {_fmt(a)} {tok} {_fmt(b)} = {_fmt(value)}, push {_fmt(value)}"
            stack.append(value)
        else:
            stack.append(float(tok))
            action = f"Push {tok}"
        steps.append({
            "token": tok,
            "action": action,
            "stack": " ".join(_fmt(v) for v in stack),
        })
    return _fmt(stack[0]), steps


def solve(expression):
    """Convert an infix string and (when possible) evaluate it."""
    tokens = tokenize(expression)
    postfix, convert_steps = infix_to_postfix(tokens)
    answer, eval_steps = evaluate_postfix(postfix)
    return {
        "infix": " ".join(tokens),
        "postfix": " ".join(postfix),
        "convert_steps": convert_steps,
        "answer": answer,
        "eval_steps": eval_steps,
    }
