/* Animated matrix background (adapted from your interactive_web_background_generator.html).
   Falling hex digits and math symbols in green. Move the mouse to light up nearby
   columns, click for a ripple. Edit the settings below to change the look. */
(function () {
    const canvas = document.getElementById("bg-canvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");

    // ---------- Settings ----------
    const FONT_SIZE = 16;
    const SPEED = 0.8;        // 1 = original speed
    const GLOW = 0.8;         // 0 turns the glow off
    const RADIUS = 150;       // how far the cursor lights up the rain
    const FADE = "rgba(4, 11, 9, 0.2)";   // trail length: lower alpha = longer trails
    const COLORS = { main: "#10b981", bright: "#6ee7b7" };
    const CHARS = "0123456789ABCDEF+-*/^%()[]{}<>";
    // ------------------------------

    let width = 0, height = 0, columns = [];
    const waves = [];
    const mouse = { x: -9999, y: -9999, active: false };
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let paused = reduceMotion;

    function resize() {
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        width = window.innerWidth;
        height = window.innerHeight;
        canvas.width = width * dpr;
        canvas.height = height * dpr;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.fillStyle = "#050b09";
        ctx.fillRect(0, 0, width, height);

        columns = [];
        for (let i = 0; i < Math.floor(width / FONT_SIZE); i++) {
            columns.push({
                x: i * FONT_SIZE,
                y: Math.random() * -height,
                speed: Math.random() * 3 + 2,
            });
        }
    }

    function draw() {
        ctx.fillStyle = FADE;
        ctx.fillRect(0, 0, width, height);
        ctx.font = FONT_SIZE + "px ui-monospace, Consolas, 'Courier New', monospace";

        for (const col of columns) {
            col.y += col.speed * SPEED * 2;
            if (col.y > height && Math.random() > 0.95) col.y = Math.random() * -100;

            const lit = mouse.active && Math.hypot(col.x - mouse.x, col.y - mouse.y) < RADIUS;
            const color = lit ? COLORS.bright : COLORS.main;
            ctx.fillStyle = color;
            ctx.shadowColor = color;
            ctx.shadowBlur = (lit ? 14 : 8) * GLOW;
            ctx.fillText(CHARS[Math.floor(Math.random() * CHARS.length)], col.x, col.y);
        }
        ctx.shadowBlur = 0;

        for (let i = waves.length - 1; i >= 0; i--) {
            const w = waves[i];
            w.radius += 4 * SPEED;
            w.alpha -= 0.02 * SPEED;
            if (w.alpha <= 0) { waves.splice(i, 1); continue; }
            ctx.beginPath();
            ctx.arc(w.x, w.y, w.radius, 0, Math.PI * 2);
            ctx.strokeStyle = COLORS.bright;
            ctx.lineWidth = 2;
            ctx.globalAlpha = w.alpha;
            ctx.stroke();
            ctx.globalAlpha = 1;
        }
    }

    function loop() {
        if (!paused) draw();
        requestAnimationFrame(loop);
    }

    window.addEventListener("resize", resize);
    window.addEventListener("mousemove", (e) => { mouse.x = e.clientX; mouse.y = e.clientY; mouse.active = true; });
    document.addEventListener("mouseleave", () => { mouse.active = false; });
    window.addEventListener("touchmove", (e) => {
        if (e.touches.length) { mouse.x = e.touches[0].clientX; mouse.y = e.touches[0].clientY; mouse.active = true; }
    }, { passive: true });
    window.addEventListener("click", (e) => {
        if (reduceMotion || e.target.closest("a, button, input, label")) return;
        waves.push({ x: e.clientX, y: e.clientY, radius: 10, alpha: 1 });
    });

    // Pause / play button
    const toggle = document.getElementById("bg-toggle");
    if (toggle) {
        const sync = () => {
            toggle.textContent = paused ? "Play background" : "Pause background";
            toggle.setAttribute("aria-pressed", String(paused));
        };
        toggle.addEventListener("click", () => { paused = !paused; sync(); });
        sync();
    }

    resize();
    if (reduceMotion) for (let i = 0; i < 150; i++) draw();  // one still frame for people who prefer no motion
    loop();
})();
