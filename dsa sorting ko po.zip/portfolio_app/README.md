# Airolle's Flask Portfolio (dark green matrix theme)

A personal portfolio site built with Flask.

## Quick start

**Windows:** double-click `run.bat`
**Mac / Linux:** run `./run.sh` in a terminal

The script creates a virtual environment, installs Flask, and starts the site.
Then open http://127.0.0.1:5000 in your browser.

### Or do it by hand

```
python -m venv venv
venv\Scripts\activate          (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
python app.py
```

## What to personalize

| What | Where |
| --- | --- |
| Your name in the header and page titles | `templates/base.html` |
| Home page text | `templates/index.html` |
| Profile (name, section, course, subject, motto, skills) | `templates/profile.html` |
| Contact details | `templates/contact.html` |
| Your photo | replace `static/images/me.jpg` with another square photo (keep the name `me.jpg`) |
| Colors and fonts | the `:root` block at the top of `static/style.css` |
| Background animation (speed, glow, colors, characters) | the settings at the top of `static/background.js` |

## Project layout

```
app.py            routes (pages) and form handling
linked_list.py    the linked list class
queue_ds.py       the queue class (enqueue, dequeue, peek)
postfix.py        infix to postfix conversion and evaluation
sorting.py        bubble, selection, insertion, merge and quick sort (with step recording)
static/           style.css, background.js (animated background) and images
templates/        HTML pages (all extend base.html)
```

## Pages

- `/` Home
- `/profile` Profile
- `/works` List of programs
- `/works/uppercase` Uppercase converter
- `/works/area/circle` Area of a circle
- `/works/area/triangle` Area of a triangle
- `/works/linkedlist` Linked list (add, insert, find, delete, reverse, clear)
- `/works/queue` Queue (enqueue, dequeue, peek, clear), first in first out
- `/works/postfix` Infix to postfix converter with step-by-step solution and answer
- `/works/sorting` Sorting: bubble, selection, insertion, merge and quick sort, with every step, counts and a comparison of all five
- `/contact` Contact

The linked list and the queue are kept in memory, so they reset when the server restarts.
