import math

from flask import Flask, render_template, request

from linked_list import LinkedList
from postfix import ExpressionError, solve
from queue_ds import Queue
from sorting import ALGORITHMS, SortError, solve as solve_sort

app = Flask(__name__)

# One list kept in memory (it resets whenever the server restarts).
linked_list = LinkedList()
queue = Queue()


def to_number(raw):
    """Convert form text to a positive float. Returns None if it isn't valid."""
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return None
    return value if value > 0 else None


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/profile")
def profile():
    return render_template("profile.html")


@app.route("/contact")
def contact():
    return render_template("contact.html")


@app.route("/works")
def works():
    return render_template("works.html")


@app.route("/works/uppercase", methods=["GET", "POST"])
def uppercase():
    result = None
    if request.method == "POST":
        result = request.form.get("inputString", "").upper()
    return render_template("touppercase.html", result=result)


@app.route("/works/area/circle", methods=["GET", "POST"])
def circle():
    result, error = None, None
    if request.method == "POST":
        radius = to_number(request.form.get("radius"))
        if radius is None:
            error = "Enter a radius greater than 0."
        else:
            result = round(math.pi * radius ** 2, 2)
    return render_template("circle.html", result=result, error=error)


@app.route("/works/area/triangle", methods=["GET", "POST"])
def triangle():
    result, error = None, None
    if request.method == "POST":
        base = to_number(request.form.get("base"))
        height = to_number(request.form.get("height"))
        if base is None or height is None:
            error = "Enter a base and a height greater than 0."
        else:
            result = round(0.5 * base * height, 2)
    return render_template("triangle.html", result=result, error=error)


@app.route("/works/linkedlist", methods=["GET", "POST"])
def linkedlist():
    message = None
    if request.method == "POST":
        action = request.form.get("action")
        value = request.form.get("value", "").strip()
        position = request.form.get("position", "").strip()

        if action == "reverse":
            linked_list.reverse()
            message = "List reversed."
        elif action == "clear":
            linked_list.clear()
            message = "List cleared."
        elif not value:
            message = "Type a value first."
        elif action == "append":
            linked_list.append(value)
            message = f"Added {value} to the end."
        elif action == "prepend":
            linked_list.prepend(value)
            message = f"Added {value} to the start."
        elif action == "insert":
            if position.isdigit() and linked_list.insert_at(int(position), value):
                message = f"Inserted {value} at position {position}."
            else:
                message = "That position is outside the list."
        elif action == "delete":
            if linked_list.delete(value):
                message = f"Deleted {value}."
            else:
                message = f"{value} is not in the list."
        elif action == "search":
            index = linked_list.search(value)
            if index == -1:
                message = f"{value} is not in the list."
            else:
                message = f"{value} is at position {index}."

    return render_template("linkedlist.html", items=linked_list.to_list(), message=message)


@app.route("/works/queue", methods=["GET", "POST"])
def queue_page():
    message = None
    if request.method == "POST":
        action = request.form.get("action")
        value = request.form.get("value", "").strip()

        if action == "dequeue":
            removed = queue.dequeue()
            message = "The queue is empty, nothing to dequeue." if removed is None else f"Dequeued {removed} from the front."
        elif action == "peek":
            front = queue.peek()
            message = "The queue is empty." if front is None else f"The front item is {front}."
        elif action == "clear":
            queue.clear()
            message = "Queue cleared."
        elif action == "enqueue":
            if value:
                queue.enqueue(value)
                message = f"Enqueued {value} at the rear."
            else:
                message = "Type a value first."

    return render_template("queue.html", items=queue.to_list(), message=message)


@app.route("/works/postfix", methods=["GET", "POST"])
def postfix():
    expression = request.values.get("expression", "").strip()
    solution, error = None, None
    if expression:
        try:
            solution = solve(expression)
        except ExpressionError as problem:
            error = str(problem)
    elif request.method == "POST":
        error = "Type an infix expression first."
    return render_template(
        "postfix.html", expression=expression, solution=solution, error=error
    )


@app.route("/works/sorting", methods=["GET", "POST"])
def sorting():
    values = request.values.get("values", "").strip()
    algorithm = request.values.get("algorithm", "bubble")
    descending = request.values.get("order") == "desc"
    solution, error = None, None
    if values:
        try:
            solution = solve_sort(values, algorithm, descending)
        except SortError as problem:
            error = str(problem)
    elif request.method == "POST":
        error = "Type some values first, such as 5, 3, 8, 1."
    return render_template(
        "sorting.html",
        values=values,
        algorithm=algorithm,
        descending=descending,
        algorithms=ALGORITHMS,
        solution=solution,
        error=error,
    )


if __name__ == "__main__":
    app.run(debug=True)
